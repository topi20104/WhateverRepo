package dao;
 
import java.sql.*;

import data.user;
 /**
  * 
  * @author Topi
  * This Class is used for same purposes as Dao class. This is just modified for only using
  * User attributes. For example if we want to have something related to session or user we use this class. 
  */
public class UserDao {
	/**
	 * Method for checking if the username and password are correct. If they are correct
	 * then the method will allow the login. Otherwise it will not. It's working
	 * by comparing the clients input to databases records.
	 * @param Kayttajanimi Is used for username
	 * @param Salasana Is used for password
	 * @return If the values sent from client side are true then it's gonna return true value with User values.
	 * In this case those values would be Username and Password.
	 * @throws SQLException 
	 * @throws ClassNotFoundException
	 */
    public user checkLogin(String Kayttajanimi, String Salasana) throws SQLException,
            ClassNotFoundException {
        String jdbcURL = "jdbc:mysql://localhost:3306/vaalikone";
        String dbUser = "topi";
        String dbPassword = "assmen123";
 
        Class.forName("com.mysql.jdbc.Driver");
        Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);
        String sql = "SELECT * FROM ehdokkaat WHERE Kayttajanimi = ? and Salasana = ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setString(1, Kayttajanimi);
        statement.setString(2, Salasana);
        
 
        ResultSet result = statement.executeQuery();
 
        user user= null;
 
        if (result.next()) {
            user = new user();
            user.setKayttajanimi(result.getString("Kayttajanimi"));
            user.setSalasana(Salasana);
            
        }
 
       
 
        return user;
    }
}