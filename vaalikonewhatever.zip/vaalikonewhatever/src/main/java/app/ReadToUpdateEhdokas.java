package app;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Dao;
import data.ehdokas;

/**
 * 
 * @author Topi
 *	Class made for showing one particular candidate.
 */
@WebServlet("/readtoupdateehdokasshow")
public class ReadToUpdateEhdokas extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Dao dao;
	public void init() {
		dao=new Dao("jdbc:mysql://localhost:3306/vaalikone", "topi", "assmen123");
	}
       
    public ReadToUpdateEhdokas() {
        super();
        // TODO Auto-generated constructor stub
    }
    /**
     * doGet function here gets the id from jsp page and then continues that id to Dao. 
     * Database collects values based on that id and shows them in show_ehdokas.jsp
     */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id=request.getParameter("id");
		ehdokas g=null;
		if (dao.getConnection()) {
			g=dao.readehdokasshow(id);
		}
		request.setAttribute("ehdokasshow", g);
		
		RequestDispatcher rd=request.getRequestDispatcher("/jsp/show_ehdokas.jsp");
		rd.forward(request, response);
	}
}
