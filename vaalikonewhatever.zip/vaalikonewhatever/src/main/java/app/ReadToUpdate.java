package app;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Dao;
import data.ehdokas;

/**
 * 
 * @author Topi
 * Class made for updating candidates. 
 */
@WebServlet("/readtoupdate")
public class ReadToUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Dao dao;
	public void init() {
		dao=new Dao("jdbc:mysql://localhost:3306/vaalikone", "topi", "assmen123");
	}
       
    public ReadToUpdate() {
        super();
        // TODO Auto-generated constructor stub
    }
    /**
     * This doGet function gets button input from jsp where admin chooses candidate to edit.
     * It gets the parameter, passes it to Dao to check which candidate to pick from database.
     * Then it forwards these candidate informations to the jsp form where we can edit those.
     */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id=request.getParameter("id");
		ehdokas f=null;
		if (dao.getConnection()) {
			f=dao.readehdokas(id);
		}
		request.setAttribute("ehdokas", f);
		
		RequestDispatcher rd=request.getRequestDispatcher("/jsp/update_ehdokkaat.jsp");
		rd.forward(request, response);
	}
}
