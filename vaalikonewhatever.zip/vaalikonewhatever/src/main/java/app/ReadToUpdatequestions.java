package app;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Dao;
import data.questions;

/**
 * 
 * @author Topi
 *	Class made for reading questions. This servlet is under work for future where you could edit questions.
 */
@WebServlet("/readtoupdatequestions")
public class ReadToUpdatequestions extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Dao dao;
	public void init() {
		dao=new Dao("jdbc:mysql://localhost:3306/vaalikone", "topi", "assmen123");
	}
       
    public ReadToUpdatequestions() {
        super();
        // TODO Auto-generated constructor stub
    }
    /**
     * basic doGet that gets the question from database based on the id that is passed from client side.
     * 
     */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id=request.getParameter("id");
		questions f=null;
		if (dao.getConnection()) {
			f=dao.readQuestions(id);
		}
		request.setAttribute("questions", f);
		
		RequestDispatcher rd=request.getRequestDispatcher("/jsp/show_question.jsp");
		rd.forward(request, response);
	}
}
