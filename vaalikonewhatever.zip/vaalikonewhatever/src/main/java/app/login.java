package app;
 
import java.io.*;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import dao.UserDao;
import data.ehdokas;
import data.user;
/**
 *  
 * @author Topi
 *	Class made for login. 
 */
@WebServlet("/login")
public class login extends HttpServlet {
    private static final long serialVersionUID = 1L;
 
    public login() {
        super();
    }
    ArrayList<ehdokas> list=null;
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
    }
    /**
     * doPost function gets form values from login page that are then used to first validate
     * the code on checklogin part. If the login is successful it's gonna enter the if statement
     * and start the session. It's gonna set few session attributes that can be then used
     * later on during the session. If the login was not correct it's gonna go to else statement
     * and keep you on the current page until you can login with proper values.
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String Kayttajanimi = request.getParameter("Kayttajanimi");
        String Salasana     = request.getParameter("Salasana");
        String redirect = "../jsp/login.jsp";
         
        UserDao userDao = new UserDao();
         
        try {
             user user = userDao.checkLogin(Kayttajanimi, Salasana);
             String username = Kayttajanimi;
             String password = Salasana;

            if (user != null) {
                HttpSession session = request.getSession();
                session.setAttribute("username", username);
                session.setAttribute("salasana", password);
                redirect = "http://localhost:8080";
            
            } else {
                String message = "Invalid email/password";
                request.setAttribute("message", message);
            }
            
            response.sendRedirect(redirect);

        } catch (SQLException | ClassNotFoundException ex) {
            throw new ServletException(ex);
        }
    }
}