package app;
 
import java.io.*;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
 /**
  * 
  * @author Topi
  * Logout class that is under work. It is gonna be used in the later work
  * where the login button will be replaced with logout if the session is active.
  * Made purely for the purpose of candidates answering and admin usage.
  */
@WebServlet("/logout")
public class logout extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    public logout() {
        super();
    }
    /**
     * Just basic doGet that gets button input from jsp file that is then used to just close the session
     * with session.invalidate() function. After this it just redirects you to the main page.
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
    	 HttpSession session = request.getSession(false);
         if (session != null) {
             session.invalidate();
             
             
         }
         String redirect = "http://localhost:8080/";
         response.sendRedirect(redirect);
		
    }
 
    
    
}