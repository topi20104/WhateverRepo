package app;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.Dao;
import data.vastaus;

@WebServlet(
    name = "saveResults",
    urlPatterns = {"/saveResults"}
)
/**
 * 
 * @author Topi
 *	Class made for saving candidate results to database.
 */
public class saveResults extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Dao dao;
	public void init() {
		dao=new Dao("jdbc:mysql://localhost:3306/vaalikone", "topi", "assmen123");
	}
	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) 
	     throws IOException {	
	}
	/**
	 * doPost function made for collecting and sending information to database.
	 * 1. HttpSession gets started.
	 * 2. We initialize answer value that can be later used. 
	 * 3. We set attribute that is current session attribute of the candidate. 
	 * 4. We have for loop for going through the answers and taking all the needed variables that can 
	 * be then passed on to the database. IF one of the answers are empty that is fine. 
	 * We can update that value later if the candidate wishes to update values.
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) 
	     throws IOException, ServletException {
			HttpSession session = request.getSession();
			String answer = "";
			String Kayttajanimi = session.getAttribute("username").toString();

			int QID = 0;
			
			for (int i=1;i<20;i++) {
				String comm ="comment" + Integer.toString(i);
				String comment = request.getParameter(comm);
				String test = Integer.toString(i);
				String ans = request.getParameter(test);
				QID++;
				System.out.println("Question id " + QID);
				System.out.println(ans);
				System.out.println(answer);
				vastaus f=new vastaus(Kayttajanimi, ans, QID, comment);
				System.out.println(answer);
				if (dao.getConnection()) {
					dao.insertAnswers(f);
					continue;
				}
			}
	}
}