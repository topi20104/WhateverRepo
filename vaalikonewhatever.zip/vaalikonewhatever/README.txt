This notepad has all the info for using this vaalikone. 
Database is included in the dumbfile.
Username for Database: topi
Password for Database: assmen123

Jar files used : 
		Web-app libraries:
		 jstl- 1.2.jar
		 mysql-connector-java-5.1.44.jar
		
		JUnit 4:
		 org.junit_4.13.0.v20200204-1500.jar
		 org.hamcrest.core_1.3.0.v20180420-1519.jar
		
		App Engine Standard Runtime:
		 javax.servlet-api-3.1.0.jar
		 javax.servlet.jsp-api-2.3.0.jar

Application should run when imported (TESTED!).

Mysql ver 5.7.33
Python ver 3.6.4


